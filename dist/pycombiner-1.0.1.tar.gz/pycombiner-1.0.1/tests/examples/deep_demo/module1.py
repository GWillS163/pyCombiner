from subdir.deeper import module3
print("This is module1.")
