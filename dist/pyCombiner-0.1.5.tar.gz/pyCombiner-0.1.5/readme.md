# The Function of PyCombiner

it is a commandline tool to combine python files into one file.
The generated resultant and usage is like pyinstaller, but is much simpler, and resultant is not ".exe", is ".py".

<img src="https://github.com/GWillS163/pyCombiner/raw/master/res/introImg.png">


