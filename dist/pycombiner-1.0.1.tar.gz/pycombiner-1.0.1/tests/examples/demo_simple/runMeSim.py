import update as up
from bin import *

# 4
up.showBanner()
main()
