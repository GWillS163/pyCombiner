# 5
from config import *
from bin import *

# CN: 只是一个demo
# EN: Just a demo_complicate
main(welcomeBanner)
