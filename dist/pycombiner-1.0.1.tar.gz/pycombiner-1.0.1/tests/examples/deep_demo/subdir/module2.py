import subdir.deeper.module3
print("This is module2.")

if __name__ == "__main__":
    print("Other Entrance")