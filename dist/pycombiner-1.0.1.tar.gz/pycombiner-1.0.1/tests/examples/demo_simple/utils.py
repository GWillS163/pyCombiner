# 2
import os

def showLogin():
    print('=' * 40)
    print("Login success")
    print('=' * 40)
    print(os.path.abspath(__file__))


def showExit():
    print('=' * 40)
    # show menu
    print('Exited')
    print('=' * 40)
