# Github: GWillS163
# User: 駿清清 
# Date: 02/11/2022 
# Time: 10:56

import os
import sys
lastDir = "../demo_simple"
sys.path.append(lastDir)
os.chdir(lastDir)
print(os.listdir("."))

