from subdir.deeper.deepest import module4
print("This is module3.")
