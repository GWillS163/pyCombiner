from utils import *

# 3
def main():
    print("Hello World!")
    showLogin()
    showExit()
