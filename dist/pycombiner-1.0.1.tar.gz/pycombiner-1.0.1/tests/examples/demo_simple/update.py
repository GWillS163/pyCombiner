# 1
def showBanner():
    print('=' * 40)
    print('Welcome to the system')
    print('=' * 40)
